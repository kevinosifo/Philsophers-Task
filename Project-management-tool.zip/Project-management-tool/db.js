
const mysql = require('mysql2');//import mysql2 package

const connection = mysql.createConnection({
    host: 'localhost',//database server
    user: 'root',  // sql user
    password: 'collytrimz12',  // sql password
    database: 'project_management'  // name of database i am connecting to
});
// Connect to the database
connection.connect(err => {
    if (err) {
      console.error('Error connecting to MySQL database:', err);
      return;
    }
    console.log('Connected to MySQL database');
  });
  
  module.exports = connection;  // Export the connection for use in other files