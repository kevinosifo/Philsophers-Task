// server/routes.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt'); // For password hashing
const db = require('./db'); // Database connection

// Signup Route
router.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send('Username and password are required');
  }

  try {
    // Hash the password
    const passwordHash = await bcrypt.hash(password, 10);

    // Insert user into the database
    const query = 'INSERT INTO users (username, password_hash) VALUES (?, ?)';
    db.query(query, [username, passwordHash], (err, result) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).send('Username already exists');
        }
        console.error(err);
        return res.status(500).send('Database error');
      }

      // Success
      res.status(201).send('Sign Up Successful');
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Login Route (This route is assumed based on your login.js)
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send('Username and password are required');
  }

  // Check if username exists in the database
  const query = 'SELECT * FROM users WHERE username = ?';
  db.query(query, [username], async (err, results) => {
    if (err) {
      return res.status(500).send('Database error');
    }
    if (results.length === 0) {
      return res.status(400).send('Username does not exist');
    }

    // Compare the provided password with the stored password hash
    const user = results[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(400).send('Incorrect password');
    }

    // Successful login
    res.status(200).json({ message: 'Login successful' });
  });
});

module.exports = router;


