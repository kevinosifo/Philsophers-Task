/*create database*/
use project_management;

/*Table for Project Managers (Authentication)*/
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/*table to store the employees*/
create table employees(
employee_id int Auto_increment primary key, 
name varchar (100) Not NULL,
role varchar (100) NOT NULL,
skill_set varchar (255) NOT NULL,
availability_status ENUM('Available', 'Busy') DEFAULT 'Available',
current_workload INT DEFAULT 0, /*tracks the number of tasks assigned*/
past_performance_score float default 0.0 /*Average performance score*/
);

/*Table to store projects */
Create table projects (
project_id int auto_increment primary key,
project_name varchar (255) NOT NULL,
client_name varchar (255),
start_date DATE  NOT NULL, 
end_date DATE NOT NULL,
budget DECIMAL(10,2) NOT NULL,
status ENUM('Not started', 'In Progress', 'completed', 'on Hold') Default 'Not started'
);
/*Table to store tasks within a project*/
Create table tasks(
task_id INT AUTO_INCREMENT PRIMARY KEY,
project_id INT NOT NULL,
task_name varchar(255) NOT NULL,
description text,
assigned_to int, 
start_date date,
end_date date,
urgency_level ENUM('LOW', 'MEDIUM', 'HIGH') NOT null,
status ENUM('Not Started', 'In Progress', 'Completed', 'Blocked') DEFAULT 'Not Started',
FOREIGN KEY (project_id) REFERENCES projects(project_id),
FOREIGN KEY (assigned_to) REFERENCES employees(employee_id)
);

/*Table to track equipment/resources*/
CREATE TABLE resources (
resource_id INT AUTO_INCREMENT PRIMARY KEY,
resource_name VARCHAR(255) NOT NULL,
resource_type VARCHAR(100) NOT NULL,
status ENUM('Available', 'In Use') DEFAULT 'Available'
);

/*Table to assign resources to tasks*/
CREATE TABLE task_resources (
task_id INT NOT NULL,
resource_id INT NOT NULL,
assigned_date DATE NOT NULL,
FOREIGN KEY (task_id) REFERENCES tasks(task_id),
FOREIGN KEY (resource_id) REFERENCES resources(resource_id),
PRIMARY KEY (task_id, resource_id)
);

/*Table to track real-time budget usage*/
CREATE TABLE budget_tracking (
    project_id INT NOT NULL,
    expense_name VARCHAR(255),
    expense_amount DECIMAL(10, 2),
    expense_date DATE,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

 /*Table for tracking employee performance on tasks*/
CREATE TABLE task_performance (
    task_id INT NOT NULL,
    employee_id INT NOT NULL,
    performance_score FLOAT CHECK (performance_score >= 0 AND performance_score <= 5),
    feedback TEXT,
    FOREIGN KEY (task_id) REFERENCES tasks(task_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    PRIMARY KEY (task_id, employee_id)
);








