document.addEventListener('DOMContentLoaded', () => {
  const signupForm = document.getElementById('signupForm');

  // Check if the signup form exists
  if (signupForm) {
    signupForm.addEventListener('submit', async (event) => {
      event.preventDefault(); // Prevent default form submission

      // Get the values of the username and password fields
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();

      // Log the values to check if they are captured correctly
      console.log('Username:', username);
      console.log('Password:', password);

      // Validate if both fields are filled out
      if (!username || !password) {
        alert('Please fill in all fields');
        return;
      }

      try {
        console.log('Sending fetch request...');

        // Send POST request to the backend API to create a new user
        const response = await fetch('/api/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }), // Send the username and password
        });

        console.log('Response received:', response);

        // Check if the response is OK (status 200-299)
        if (response.ok) {
          alert('Sign-Up Successful');
          window.location.href = '/login.html'; // Redirect to the login page after successful signup
        } else {
          // If sign-up failed, show the error message from the backend
          const errorText = await response.text();
          alert(`Sign-Up Failed: ${errorText}`);
        }
      } catch (error) {
        console.error('Error during sign-up:', error);
        alert('An error occurred during sign-up');
      }
    });
  } else {
    console.error('Sign-up form not found');
  }
});
